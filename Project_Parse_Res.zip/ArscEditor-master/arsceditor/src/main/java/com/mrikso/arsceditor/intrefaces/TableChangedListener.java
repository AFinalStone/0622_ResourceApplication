package com.mrikso.arsceditor.intrefaces;

public interface TableChangedListener {

    void tableChanged();
}
