package com.thereisnospon.util.parse.type;

import java.util.List;

/**
 * Created by yzr on 2018/6/20.
 */
public class ResStringPoolSpanList {
    /**
     * 一个 style 对应的 string span
     */
    public List<ResStringPoolSpan> spans;
}
