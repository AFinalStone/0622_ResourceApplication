package com.thereisnospon.util.parse.type;

/**
 * Created by yzr on 2018/6/20.
 */
public class ResTableRef {
	
	public int ident;
	
	public  static int getSize(){
		return 4;
	}

}
