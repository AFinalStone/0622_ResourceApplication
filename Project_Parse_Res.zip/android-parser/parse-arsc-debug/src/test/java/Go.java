/**
 * Created by yzr on 2018/7/1.
 */
public class Go {

    public static void main(String []args){

    }

}
