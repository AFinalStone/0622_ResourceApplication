package com.hjy.resourcesparse.type;

/**
 * Created by hjy on 2019/4/29.
 */

public class ResStringPoolSpan {

    public ResStringPoolRef name;
    public int firstChar;
    public int lastChar;

}
