package com.hjy.resourcesparse.type;

/**
 * Created by hjy on 2019/4/29.
 */

public class ResStringPoolRef {

    public int index;

    @Override
    public String toString() {
        return "ResStringPoolRef{" +
                "index=" + index +
                '}';
    }
}
