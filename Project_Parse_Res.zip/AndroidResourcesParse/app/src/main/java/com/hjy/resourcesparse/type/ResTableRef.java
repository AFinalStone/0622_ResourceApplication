package com.hjy.resourcesparse.type;

public class ResTableRef {

    public int ident;

    @Override
    public String toString() {
        return "ResTableRef{" +
                "ident=" + ident +
                '}';
    }
}
