如何解析Android包中的resources.arsc文件

https://www.jianshu.com/p/4fa359b62ae3
